npm install knex -g
npm install
knex migrate:latest